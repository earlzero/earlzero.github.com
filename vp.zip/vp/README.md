# Installation
I've chosen gradle as build system for task. It doesn't require explicit installation -
you can launch it from project directory and it will download itself and all depencencies.
You either can use binary from videoplaza.zip or create new one with command:
./gradlew distZip
Created file will be in directory build/distributions/
After unpacking file you should run command (I checked it on MacOS and linux, probably videoplaza.bat will work on windows) in directory videoplaza.
> ./bin/videoplaza server videoplaza.yaml

To launch test request (Sample problem 3) you can run
> curl -i --data-ascii @request.json -H "Content-Type: application/json" http://localhost:8080/videoplaza
Calculation result url is in body of returned response. By using GET on this request you can get JSON with calculation result.

#Working with service.
Service provides two methods - one for starting new calculation and another for retrieving calculation results. 

## New calculation request
Request url: /videoplaza
Request parameters:
* type of request - POST
* Content-Type: application/json

Example of sending request with curl
> curl -i --data-ascii @request.json -H "Content-Type: application/json" http://localhost:8080/videoplaza

###Request body format:
Request is JSON document there are two main fields - "inventory" (it contains number of available impressions) and "customers" (list of customers with their name, campaign size, and revenue).
Example request:
> {"customers":[{"name":"Acme","impressions":1,"revenue":1},{"name":"Lorem","impressions":2,"revenue":3}],"inventory":5}

###Response format
Successfull response contains link to calculation results. Response status is 201, Location header contains link to calculation result, for convenience same link is contained in body. Link is example of calculation retrieval request. If request was incorrect (negative impressions or revenue) code 400 will be returned.

## Calculation retrieval request.
Request url: /videoplaza/{id}
This request is simple GET-request. It shouldn't contain any body or parameters except "id" provided in url.

###Response format
There could be three possible responses:
* 404 - incorrect or expired identifier
* 202 - calculation is still in progress.
* 200 - calculation finished. Body contains calculation result.

###Successfull body response format
* state - result of calculation. It should be "FINISHED" always
* result - field contains result of calculation
  There are fields:
	* results - list of customers with they name ("customer"), number of campaigns ("campaigns"), number if impressions("impressions") and revenue ("revenue").
	* impressions - total number of impressions used
	* revenue - revenue, that could be achieved with this solution of the problem
	* precision - this field coult contain two values:
		* FULL - it is used, when task was solved by precise algorithm (Unbounded knapsack problem dynamic programming algorithm).
		* HALF - used, then problem was solved by greedy knapsack heuristic (it is used, when precise algorithm couldn't find solution in {timeout} seconds). 

> {"state":"FINISHED","result":{"results":[{"customer":"Acme","campaigns":1,"impressions":1,"revenue":1},{"customer":"Lorem","campaigns":2,"impressions":4,"revenue":6}],"impressions":5,"revenue":7,"precision":"FULL"}}


# Other comments
Current implementation use 3 gigabytes of memory, but if it will be launched on machine with lower memory, gradle.properties should be modified.
You can generate eclipse project to review code faster
> ./gradlew eclipse
Project contains unit and integration tests which can be launched with
> ./gradlew test
Application can be runned with command
> ./gradlew run
There are couple of configuration options in videoplaza.yml:
* port - application port
* timeout - timeout for dynamic programming algorithm for knapsack optimization. Value near 55 seconds should be ok.
