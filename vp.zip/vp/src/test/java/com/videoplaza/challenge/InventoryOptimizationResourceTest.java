package com.videoplaza.challenge;

import io.dropwizard.testing.junit.DropwizardAppRule;

import javax.ws.rs.core.MediaType;

import org.junit.Assert;
import org.junit.ClassRule;
import org.junit.Test;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.videoplaza.challenge.optimization.Customer;
import com.videoplaza.challenge.optimization.Result;
import com.videoplaza.challenge.optimization.Task;
import com.videoplaza.challenge.service.Forecast;
import com.videoplaza.challenge.service.ForecastState;
import com.videoplaza.challenge.service.InventoryOptimizerApplication;
import com.videoplaza.challenge.service.InventoryOptimizerConfiguration;

public class InventoryOptimizationResourceTest {

	@ClassRule
	public static final DropwizardAppRule<InventoryOptimizerConfiguration> RULE = new DropwizardAppRule<InventoryOptimizerConfiguration>(
			InventoryOptimizerApplication.class,
			InventoryOptimizationResourceTest.class.getResource(
					"/videoplaza.yml").getFile());

	@Test
	public void testSimpleOptimization() throws Exception {
		Client client = new Client();

		client.setFollowRedirects(true);

		Customer c1 = new Customer("a", 2, 3);
		Customer c2 = new Customer("b", 1, 1);

		Task t = new Task();
		t.getCustomers().add(c1);
		t.getCustomers().add(c2);
		t.setInventory(5);

		ClientResponse response = client
				.resource(
						String.format("http://localhost:%d/videoplaza",
								RULE.getLocalPort()))
				.type(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.post(ClientResponse.class, t);

		Assert.assertEquals(201, response.getStatus());
		String result = response.getHeaders().get("Location").get(0);

		Thread.sleep(5000);//should be enough

		Forecast f = client.resource(result).accept(MediaType.APPLICATION_JSON)
				.get(Forecast.class);
		Assert.assertEquals(ForecastState.FINISHED, f.getState());
		Result r = f.getResult();
		Assert.assertEquals(5, r.getImpressions());
	}
	
	
	@Test
	public void testFail() throws Exception {
		Client client = new Client();

		client.setFollowRedirects(true);

		Customer c1 = new Customer("a", -2, 3);
		Customer c2 = new Customer("b", 1, 1);

		Task t = new Task();
		t.getCustomers().add(c1);
		t.getCustomers().add(c2);
		t.setInventory(5);

		ClientResponse response = client
				.resource(
						String.format("http://localhost:%d/videoplaza",
								RULE.getLocalPort()))
				.type(MediaType.APPLICATION_JSON)
				.accept(MediaType.APPLICATION_JSON_TYPE)
				.post(ClientResponse.class, t);

		Assert.assertEquals(400, response.getStatus());
	}
}
