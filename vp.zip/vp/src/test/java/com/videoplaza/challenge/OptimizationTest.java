package com.videoplaza.challenge;

import java.util.Collections;
import java.util.concurrent.Executors;

import org.junit.Assert;
import org.junit.Test;

import com.videoplaza.challenge.optimization.CombinedKnapsackSolver;
import com.videoplaza.challenge.optimization.Customer;
import com.videoplaza.challenge.optimization.DpKnapsackSolver;
import com.videoplaza.challenge.optimization.GreedyKnapsackSolver;
import com.videoplaza.challenge.optimization.Result;
import com.videoplaza.challenge.optimization.Task;

public class OptimizationTest {

	@Test
	public void testDpKnapsack0() {
		Task t = new Task();
		
		t.setInventory(10);
		t.getCustomers().add(new Customer("Acme", 6, 30));
		t.getCustomers().add(new Customer("Lorem", 3, 14));
		t.getCustomers().add(new Customer("Ipsum", 4, 16));
		t.getCustomers().add(new Customer("Dolor", 2, 9));

		Result r = new DpKnapsackSolver().solve(t.getSimplified());

		Collections.sort(r.getResults());
		System.out.println(r.getResults());
		Assert.assertEquals(2, r.getResults().get(2).getCampaigns());
		Assert.assertEquals(1, r.getResults().get(3).getCampaigns());
	}

	@Test
	public void testDpKnapsack1() {
		Task t = new Task();
		t.setInventory(32356000l);
		t.getCustomers().add(new Customer("Acme", 2000000, 200));
		t.getCustomers().add(new Customer("Lorem", 3500000, 400));
		t.getCustomers().add(new Customer("Ipsum", 2300000, 210));
		t.getCustomers().add(new Customer("Dolor", 8000000, 730));
		t.getCustomers().add(new Customer("SIT", 10000000, 1000));
		t.getCustomers().add(new Customer("Amet", 1500000, 160));
		t.getCustomers().add(new Customer("Mauris", 1000000, 100));

		Result r = new DpKnapsackSolver().solve(t.getSimplified());
		Collections.sort(r.getResults());
		System.out.println(r.getResults());
		Assert.assertEquals(1, r.getResults().get(4).getCampaigns());
		Assert.assertEquals(2, r.getResults().get(5).getCampaigns());
		Assert.assertEquals(8, r.getResults().get(6).getCampaigns());
	}

	@Test
	public void testDpKnapsack2() {
		Task t = new Task();
		t.setInventory(2000000000l);
		t.getCustomers().add(new Customer("Acme", 1000000, 5000));
		t.getCustomers().add(new Customer("Lorem", 2000000, 9000));
		t.getCustomers().add(new Customer("Ipsum", 3000000, 20000));

		Result r = new DpKnapsackSolver().solve(t.getSimplified());

		Collections.sort(r.getResults());
		System.out.println(r.getResults());
		Assert.assertEquals(2, r.getResults().get(1).getCampaigns());
		Assert.assertEquals(666, r.getResults().get(2).getCampaigns());

	}

	@Test
	public void testCombinedKnapsack() throws Exception {
		Task t = new Task();
		t.setInventory(50000000l);
		t.getCustomers().add(new Customer("Acme", 1, 0));
		t.getCustomers().add(new Customer("Lorem", 2, 2));
		t.getCustomers().add(new Customer("Ipsum", 3, 2));
		t.getCustomers().add(new Customer("Dolor", 70000, 71000));
		t.getCustomers().add(new Customer("Mauris", 49000000l, 50000000l));

		Result r = new CombinedKnapsackSolver(Executors.newCachedThreadPool(),
				5).solve(t);

		Collections.sort(r.getResults());
		System.out.println(r.getResults());
		Assert.assertEquals(10000, r.getResults().get(2).getCampaigns());
		Assert.assertEquals(14, r.getResults().get(3).getCampaigns());
		Assert.assertEquals(1, r.getResults().get(4).getCampaigns());

	}

	@Test
	public void testGreedyKnapsack() throws Exception {
		Task t = new Task();
		t.setInventory(50000000l);
		t.getCustomers().add(new Customer("Acme", 1, 0));
		t.getCustomers().add(new Customer("Lorem", 2, 2));
		t.getCustomers().add(new Customer("Ipsum", 3, 2));
		t.getCustomers().add(new Customer("Dolor", 70000, 71000));
		t.getCustomers().add(new Customer("Mauris", 49000000l, 50000000l));

		Result r = new GreedyKnapsackSolver().solve(t);

		Collections.sort(r.getResults());
		System.out.println(r.getResults());
		Assert.assertEquals(10000, r.getResults().get(2).getCampaigns());
		Assert.assertEquals(14, r.getResults().get(3).getCampaigns());
		Assert.assertEquals(1, r.getResults().get(4).getCampaigns());

	}

	@Test
	public void testGreedyKnapsack2() throws Exception {
		Task t = new Task();
		t.setInventory(100l);
		t.getCustomers().add(new Customer("Acme", 60, 60));
		t.getCustomers().add(new Customer("Lorem", 51, 52));

		Result r = new GreedyKnapsackSolver().solve(t);

		Collections.sort(r.getResults());
		System.out.println(r.getResults());
		Assert.assertEquals(r.getResults().get(1).getCampaigns(), 1);
	}
}
