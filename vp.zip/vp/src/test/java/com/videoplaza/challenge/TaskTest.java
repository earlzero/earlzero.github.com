package com.videoplaza.challenge;

import org.junit.Assert;
import org.junit.Test;

import com.videoplaza.challenge.optimization.Customer;
import com.videoplaza.challenge.optimization.Task;

public class TaskTest {
	@Test
	public void taskTestSimplification() {
		Task task = new Task();
		task.getCustomers().add(new Customer("a", 1000, 100));
		task.getCustomers().add(new Customer("a", 500, 200));
		task.setInventory(2000);
		Task simple = task.getSimplified();
		Assert.assertEquals(simple.getInventory(), 4);
	}

}
