package com.videoplaza.challenge;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

import com.videoplaza.challenge.optimization.Customer;

public class CustomerTest {
	@Test
	public void testSortRatio() {
		List<Customer> customers = new ArrayList<>();
		customers.add(new Customer("a", 4, 8));
		customers.add(new Customer("b", 2, 2));
		customers.add(new Customer("c", 1, 12));
		Collections.sort(customers);
		Assert.assertEquals(customers.get(0).getName(), "c");
		Assert.assertEquals(customers.get(1).getName(), "a");
		Assert.assertEquals(customers.get(2).getName(), "b");
	}
	
	@Test
	public void testSortImpressions() {
		List<Customer> customers = new ArrayList<>();
		customers.add(new Customer("a", 4, 8));
		customers.add(new Customer("b", 2, 2));
		customers.add(new Customer("c", 1, 1));
		Collections.sort(customers);
		Assert.assertEquals(customers.get(0).getName(), "a");
		Assert.assertEquals(customers.get(1).getName(), "c");
		Assert.assertEquals(customers.get(2).getName(), "b");
	}
	
	@Test
	public void testSortAlphabet() {
		List<Customer> customers = new ArrayList<>();
		customers.add(new Customer("a", 4, 8));
		customers.add(new Customer("b", 1, 1));
		customers.add(new Customer("c", 1, 1));
		Collections.sort(customers);
		Assert.assertEquals(customers.get(0).getName(), "a");
		Assert.assertEquals(customers.get(1).getName(), "b");
		Assert.assertEquals(customers.get(2).getName(), "c");
	}
}
