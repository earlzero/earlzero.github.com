package com.videoplaza.challenge.optimization;

public interface KnapsackSolver {
	Result solve(Task task);
}
