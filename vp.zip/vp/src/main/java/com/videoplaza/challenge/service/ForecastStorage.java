package com.videoplaza.challenge.service;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.videoplaza.challenge.optimization.CombinedKnapsackSolver;
import com.videoplaza.challenge.optimization.KnapsackSolver;
import com.videoplaza.challenge.optimization.Result;
import com.videoplaza.challenge.optimization.Task;

public class ForecastStorage {
	private KnapsackSolver knapsackSolver;

	private LoadingCache<String, Forecast> cache;
	private ExecutorService executor;

	private class Calculator implements Runnable {

		private String id;
		private Task task;

		public Calculator(String id, Task task) {
			this.id = id;
			this.task = task;
		}

		@Override
		public void run() {
			Result result = knapsackSolver.solve(task);
			Forecast forecast;
			forecast = cache.getUnchecked(id);
			if (forecast != null) {// In time
				forecast.setResult(result);
			} else {
				forecast = new Forecast();
				forecast.setResult(result);
				cache.put(id, forecast);
			}
		}

	}

	public ForecastStorage(ExecutorService executor, int timeout) {
		this.executor = executor;
		this.knapsackSolver = new CombinedKnapsackSolver(executor, timeout);
		this.cache = CacheBuilder.newBuilder()
				.maximumSize(10000).expireAfterWrite(timeout * 2, TimeUnit.SECONDS)
				.build(new CacheLoader<String, Forecast>() {
					public Forecast load(String key) throws Exception {
						return new Forecast();
					}
				});

	}

	public String newForecast(Task task) {
		String id = UUID.randomUUID().toString();

		cache.put(id, new Forecast(ForecastState.CALCULATING));

		executor.submit(new Calculator(id, task));

		return id;
	}

	public Forecast getForecast(String id) {
		return cache.getUnchecked(id);
	}
}
