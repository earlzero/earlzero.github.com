package com.videoplaza.challenge.optimization;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GreedyKnapsackSolver implements KnapsackSolver {

	/**
	 * Greedy approximation for unbounded knapsack problem
	 * http://en.wikipedia.org
	 * /wiki/Knapsack_problem#Greedy_approximation_algorithm
	 */

	@Override
	public Result solve(Task task) {
		List<Customer> customers = new ArrayList<>(task.getCustomers());
		Collections.sort(customers);
		Map<Customer, Integer> results = new HashMap<>();
		long size = task.getInventory();
		long currentValue = 0l;
		for (Customer c : customers) {
			int count = (int) (size / c.getImpressions());
			size -= count * c.getImpressions();
			results.put(c, count);
			currentValue += count * c.getRevenue();
		}

		for (Customer c : customers) {
			if (c.getRevenue() > currentValue// Avoiding fail with single
												// valuable element
					&& c.getImpressions() <= task.getInventory()) {
				results.clear();
				for (Customer d : customers) {
					results.put(d, c.equals(d) ? 1 : 0);
				}
				break;
			}
		}

		List<ResultEntry> resultsList = Util.getResultEntries(results, 1);

		return new Result(resultsList, Precision.HALF);
	}

}
