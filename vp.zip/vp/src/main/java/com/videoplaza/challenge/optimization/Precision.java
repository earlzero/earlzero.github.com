package com.videoplaza.challenge.optimization;

public enum Precision {
	HALF, FULL;
}
