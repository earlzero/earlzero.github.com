package com.videoplaza.challenge.service;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.videoplaza.challenge.optimization.Result;

public class Forecast {
	private ForecastState state;
	private Result result;

	public Forecast() {
		this(null);
	}

	public Forecast(ForecastState state) {
		this.state = state;
	}
	
	public void setResult(Result result) {
		this.result = result;
		state = ForecastState.FINISHED;
	}

	@JsonProperty
	public ForecastState getState() {
		return state;
	}

	@JsonProperty
	public Result getResult() {
		return result;
	}
	
	
}
