package com.videoplaza.challenge.optimization;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ResultEntry implements Comparable<ResultEntry> {

	private String customer;
	private int campaigns;
	private long impressions;
	private long revenue;

	public ResultEntry()  {
	}
	
	public ResultEntry(String customer, int campaigns, long impressions,
			long revenue) {
		this.customer = customer;
		this.campaigns = campaigns;
		this.impressions = impressions;
		this.revenue = revenue;
	}

	@JsonProperty
	public String getCustomer() {
		return customer;
	}

	@JsonProperty
	public int getCampaigns() {
		return campaigns;
	}

	@JsonProperty
	public long getImpressions() {
		return impressions;
	}

	@JsonProperty
	public long getRevenue() {
		return revenue;
	}

	@Override
	public String toString() {
		return String.format("%s\t%d\t%d\t%d", customer, campaigns,
				impressions, revenue);
	}

	@Override
	public int compareTo(ResultEntry o) {
		int result = impressions > o.impressions ? 1
				: impressions < o.impressions ? -1 : 0;
		if (result == 0) {
			return customer.compareTo(o.getCustomer());
		} else {
			return result;
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + (int) (impressions ^ (impressions >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ResultEntry other = (ResultEntry) obj;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (impressions != other.impressions)
			return false;
		return true;
	}

}
