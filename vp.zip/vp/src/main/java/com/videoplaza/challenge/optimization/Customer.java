package com.videoplaza.challenge.optimization;

import javax.validation.constraints.Min;

public class Customer implements Comparable<Customer> {

	private String name;
	private long impressions;
	@Min(value = 1)
	private long revenue;

	public Customer() {
		//Jackson serialization
	}
	
	public Customer(Customer src, long denom) {
		this.name = src.getName();
		this.impressions = src.getImpressions() / denom;
		this.revenue = src.getRevenue();
	}

	public Customer(String name, long impressions, long revenue) {
		this.name = name;
		this.impressions = impressions;
		this.revenue = revenue;
	}

	public String getName() {
		return name;
	}

	public long getImpressions() {
		return impressions;
	}

	public long getRevenue() {
		return revenue;
	}


	@Override
	public int compareTo(Customer o) {

		float weight = -((float) revenue) / impressions;
		float otherWeight = -((float) o.getRevenue()) / o.getImpressions();

		if (weight < otherWeight) {
			return -1;
		} else if (weight > otherWeight) {
			return 1;
		} else {
			if (impressions < o.getImpressions()) {
				return -1;
			} else if (impressions > o.getImpressions()) {
				return 1;
			} else {
				return name.compareTo(o.getName());
			}
		}

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (impressions ^ (impressions >>> 32));
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + (int) (revenue ^ (revenue >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (impressions != other.impressions)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (revenue != other.revenue)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return String.format("%s\t%d\t%d", name, impressions, revenue);
	}
}
