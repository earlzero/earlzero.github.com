package com.videoplaza.challenge.optimization;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties
public class Task {
	private long gcd = 1;
	private long size;
	private List<Customer> customers = new ArrayList<>();

	public Task(long gcd) {
		this.gcd = gcd;
	}
	
	public Task() {
		this(1);
	}
	
	@JsonProperty
	public void setInventory(long size) {
		this.size = size;
	}

	@JsonIgnore
	public Task getSimplified() {
		long[] numbers = new long[customers.size()];
		for (int i = 0; i < numbers.length; i++) {
			numbers[i] = customers.get(i).getImpressions();
		}
		gcd = Util.gcd(numbers);
		Task result = new Task(gcd);
		for (Customer c : customers) {
			result.getCustomers().add(new Customer(c, gcd));
		}
		result.setInventory(getInventory() / gcd);
		return result;
	}

	@JsonProperty
	public void setCustomers(List<Customer> customers) {
		this.customers = customers;
	}

	@JsonProperty
	public List<Customer> getCustomers() {
		return customers;
	}

	@JsonProperty
	public long getInventory() {
		return size;
	}

	@JsonIgnore
	public long getGcd() {
		return gcd;
	}
}
