package com.videoplaza.challenge.optimization;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class CombinedKnapsackSolver implements KnapsackSolver {

	private KnapsackSolver dpKnapsackSolver = new DpKnapsackSolver();
	private KnapsackSolver greedyKnapsackSolver = new GreedyKnapsackSolver();
	private ExecutorService executor;
	private int timeout;

	public CombinedKnapsackSolver(ExecutorService executor, int timeout) {

		this.executor = executor;
		this.timeout = timeout;

	}

	private class SolverCallable implements Callable<Result> {

		private KnapsackSolver solver;
		private Task task;

		public SolverCallable(Task task, KnapsackSolver solver) {
			this.solver = solver;
			this.task = task;
		}

		@Override
		public Result call() throws Exception {
			return solver.solve(task);
		}

	}

	@Override
	public Result solve(Task task) {

		Future<Result> precise = executor.submit(new SolverCallable(task,
				dpKnapsackSolver));
		Future<Result> fast = executor.submit(new SolverCallable(task,
				greedyKnapsackSolver));
		try {
			return precise.get(timeout, TimeUnit.SECONDS);
		} catch (InterruptedException | ExecutionException | TimeoutException e) {
			try {
				return fast.get();
			} catch (InterruptedException | ExecutionException e1) {
				return null;
			}
		}

	}
}
