package com.videoplaza.challenge.optimization;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Stack;

/**
 * Dynamic programming implementation for unbounded knapsack problem
 * http://en.wikipedia.org/wiki/Knapsack_problem#Unbounded_knapsack_problem
 * 
 * @author earlzero
 *
 */
public class DpKnapsackSolver implements KnapsackSolver {

	@Override
	public Result solve(Task srcTask) {
		Task task = srcTask.getSimplified();
		int[] m = new int[((int) task.getInventory()) + 1];
		int tmp = 0;
		int pos = 0;
		Stack<Integer> backtrack = new Stack<>();
		List<Customer> customers = task.getCustomers();
		for (int i = 1; i < m.length && !Thread.interrupted(); i++) {
			m[i] = m[i - 1];
			pos = i - 1;
			for (int j = 0; j < customers.size(); j++) {
				int weight = (int) customers.get(j).getImpressions();
				int value = (int) customers.get(j).getRevenue();
				if (i >= weight) {
					tmp = m[i - weight] + value;
				}
				if (tmp > m[i]) {
					m[i] = tmp;
					pos = i - weight;
				}
			}
			backtrack.push(pos);
		}

		Map<Long, Customer> customersMap = new HashMap<>();
		Map<Customer, Integer> results = new HashMap<>();

		for (Customer c : customers) {
			if (customersMap.get(c.getRevenue()) == null) {
				customersMap.put(c.getRevenue(), c);
			} else {
				if (customersMap.get(c.getRevenue()).getImpressions() > c
						.getImpressions()) {
					customersMap.put(c.getRevenue(), c);
				}
			}
			results.put(c, 0);
		}

		int max = m[m.length - 1];
		for (int i = backtrack.size() - 1; i > 0 && !Thread.interrupted();) {
			int value = backtrack.get(i);
			if (m[value] < max) {
				long revenue = max - m[value];
				Customer c = customersMap.get(revenue);
				results.put(c, results.get(c) + 1);
				max = m[value];
			}
			if (value == i) {
				i--;
			} else {
				i = value;
			}
		}

		if (Thread.interrupted()) {
			return null;
		}

		List<ResultEntry> resultsList = Util.getResultEntries(results,
				task.getGcd());
		return new Result(resultsList, Precision.FULL);
	}
}
