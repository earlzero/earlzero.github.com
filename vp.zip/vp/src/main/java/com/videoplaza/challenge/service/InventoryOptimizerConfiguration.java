package com.videoplaza.challenge.service;

import io.dropwizard.Configuration;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

public class InventoryOptimizerConfiguration extends Configuration {

	@NotNull
	private Integer timeout;

	@JsonProperty
	public Integer getTimeout() {
		return timeout;
	}

	@JsonProperty
	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}

}
