package com.videoplaza.challenge.service;

public enum ForecastState {
	CALCULATING, FINISHED;
}
