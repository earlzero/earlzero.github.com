package com.videoplaza.challenge.service;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

import java.util.concurrent.Executors;

public class InventoryOptimizerApplication extends
		Application<InventoryOptimizerConfiguration> {

	@Override
	public String getName() {
		return "inventory-optimizer";
	}

	@Override
	public void initialize(Bootstrap<InventoryOptimizerConfiguration> bootstrap) {

	}

	@Override
	public void run(InventoryOptimizerConfiguration configuration,
			Environment environment) throws Exception {
		//There were some issues with managed executorservice from dropwizard, so I decided to create one explicitly
		ForecastStorage storage = new ForecastStorage(Executors.newCachedThreadPool(),
				configuration.getTimeout());

		InventoryOptimizerResource resource = new InventoryOptimizerResource(
				storage);

		environment.jersey().register(resource);

	}

	public static void main(String... args) throws Exception {
		new InventoryOptimizerApplication().run(args);
	}
}
