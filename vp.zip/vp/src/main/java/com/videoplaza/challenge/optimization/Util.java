package com.videoplaza.challenge.optimization;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Util {
	public static long gcd(long a, long b) {
		long p = Math.min(a, b);
		long n = Math.max(a, b);
		while (p > 0) {
			long tmp = n % p;
			n = p;
			p = tmp;
		}
		return n;
	}

	public static long gcd(long[] numbers) {
		if (numbers == null || numbers.length == 0) {
			throw new IllegalArgumentException();
		} else {
			long p = numbers[0];
			for (int i = 1; i < numbers.length; i++) {
				p = gcd(p, numbers[i]);
			}
			return p;
		}
	}

	public static List<ResultEntry> getResultEntries(
			Map<Customer, Integer> results, long gcd) {
		List<ResultEntry> resultsList = new ArrayList<>();

		for (Map.Entry<Customer, Integer> entry : results.entrySet()) {
			int campaigns = entry.getValue();
			Customer c = entry.getKey();
			long impressions = c.getImpressions() * campaigns;
			long revenue = c.getRevenue() * campaigns;
			resultsList.add(new ResultEntry(c.getName(), campaigns, impressions
					* gcd, revenue));
		}

		return resultsList;
	}
}
