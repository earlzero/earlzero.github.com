package com.videoplaza.challenge.optimization;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Result {
	private List<ResultEntry> results = new ArrayList<>();
	private long impressions;
	private long revenue;
	private Precision precision;

	public Result() {
		//Jackson serialization
	}

	public Result(List<ResultEntry> results, Precision precision) {
		this.results = results;
		this.precision = precision;
		for (ResultEntry entry : results) {
			impressions += entry.getImpressions();
			revenue += entry.getRevenue();
		}
	}

	@JsonProperty
	public List<ResultEntry> getResults() {
		return results;
	}

	@JsonProperty
	public long getImpressions() {
		return impressions;
	}

	@JsonProperty
	public long getRevenue() {
		return revenue;
	}

	@JsonProperty
	public Precision getPrecision() {
		return precision;
	}

}
