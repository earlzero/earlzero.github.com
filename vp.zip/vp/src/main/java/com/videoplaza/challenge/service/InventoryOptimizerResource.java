package com.videoplaza.challenge.service;

import java.net.URI;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import com.videoplaza.challenge.optimization.Customer;
import com.videoplaza.challenge.optimization.Task;

@Path("/videoplaza")
@Produces(MediaType.APPLICATION_JSON)
public class InventoryOptimizerResource {

	@Context
	private UriInfo uriInfo;

	private ForecastStorage storage;

	public InventoryOptimizerResource(ForecastStorage storage) {
		this.storage = storage;
	}

	private boolean isValid(Task task) {
		boolean valid = true;
		for (Customer c : task.getCustomers()) {
			valid &= c.getImpressions() >= 0 && c.getRevenue() >= 0;
		}
		return valid;
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Response calculate(Task task) {
		if (isValid(task)) {
			String result = storage.newForecast(task);
			UriBuilder ub = uriInfo.getAbsolutePathBuilder();
			URI resultUri = ub.path(result).build();
			return Response.created(resultUri).entity(resultUri).build();
		} else {
			return Response.status(400).build();
		}
	}

	@GET
	@Path("{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getResult(@PathParam("id") String id) {
		Forecast forecast = storage.getForecast(id);
		if (forecast == null || forecast.getState() == null) {// new or
																// invalidated
																// entry
			return Response.status(404).build();
		} else if (forecast.getState() == ForecastState.CALCULATING) {
			return Response.status(202).build();
		} else {
			return Response.ok().entity(forecast).build();
		}
	}
}
